// Borland C++ Builder Version 3 example DLLs for MCell.
// Example template for a 2D rule by Brian Behlendorf.

#include <vcl.h>
#include <stdlib.h>
#include <time.h>
#pragma hdrstop

// Defines the entry and exit point for the DLL application.
int WINAPI DllEntryPoint(HINSTANCE, unsigned long, void *) {
  return 1;
} /* DllEntryPoint() */

// Sample 2D rule
// Calculate the new state of the 'Me' cell.
int __stdcall __declspec(dllexport) CARule(int Generation, int col, int row,
    int NW, int N,  int NE, int W,  int Me, int E, int SW, int S,  int SE) {

  // Example 'Me' calculation.
  if (W == E)    return W;
  if (S == N)    return S;
  if (NW == SE)  return NW;
  if (NE == SW)  return NE;

  return rand() % 4;
} /* CARule() */

// CAPass() is called before and after each cycle.
void __stdcall __declspec(dllexport) CAPass(int Generation, int Population,
    int PreFlag, char *Misc) {
  return;
} /* CAPass() */

// CAClose() is called when the DLL is freed (unloaded).
void __stdcall __declspec(dllexport) CAClose(int Generation, int Population) {
  return;
} /* CAClose() */

// CASetup() is called immediatelly after this rule is selected in MCell.
void __stdcall __declspec(dllexport) CASetup(int *RuleType,
    int *CountOfColors, char *ColorPalette, char *Misc) {
  time_t t;

  *RuleType = 2;       // 1 - 1D; 2 - 2D
  *CountOfColors = 4;  // Number of states; (0..n-1)
  strcpy(ColorPalette, "Rainbow008");  // Optional color palette
  strcpy(Misc, "");    // Optional extra parameters; (none supported)

  srand((unsigned)time(&t));  // Pseudo-randomly seed the rule;
} /* CASetup() */
