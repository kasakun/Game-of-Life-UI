// MSVC6_DLA.cpp : DLA (Diffusion Limited Aggregation);
// 
// Optimized to use a Margolus neighborhood.
// Brian Behlendorf.
//

#include "stdafx.h"
#include <stdlib.h>

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


// Rules for Margolus neigborhood.  All collisions are conservative.
// These rules are complete, they may be able to be simplified. This
// feels a bit kludgy to me, but for now it'll do.  I should be able
// to simplify the rules and bitshift the rotations if speed becomes
// an issue.
//
// 1|       |1      |                         1|       |1      |2
// -+- <-> -+- <-> -+-                        -+- <-> -+- <-> -+-
//  |       |      1|                          |2     2|      1|
//
// 1|2      |1      |      2|                 1|2     2|4     3|1
// -+- <-> -+- <-> -+- <-> -+-                -+- <-> -+- <-> -+-
//  |       |2     1|2     1|                 3|4     1|3     4|2
//
// 1|2     1|2     1|      3|1     2|          |       |
// -+- <-> -+- <-> -+- <-> -+- <-> -+-        -+- <-> -+-
// 3|       |3     3|2      |2     1|3         |       |
//
//
// This isn't a perfect solution, but for the purposes of the DLA we'll
// move an entire local neighborhood to a static state when another
// static cell exists within its bounds.  This isn't ideal, however I
// think the effect will be similar.  (1-8 active; 9-16 static)
//
void __declspec(dllexport) __stdcall CARuleMG(int Generation, 
                                     int col, int row,
                                     int* ul, int* ur, int* ll, int* lr)
{
  int i, states[4] = { *ul, *ur, *lr, *ll };

  // Convert neighborhood to static behavior.
  if ((*ul > 8) || (*ur > 8) || (*lr > 8) || (*ll > 8)) 
  {
    if ((*ul <= 8) && (*ul))  *ul += 8;
    if ((*ur <= 8) && (*ur))  *ur += 8;
    if ((*lr <= 8) && (*lr))  *lr += 8;
    if ((*ll <= 8) && (*ll))  *ll += 8;
    return;
  }
  
  // Behavior based on the number of living cells in the neighborhood.
  switch ((*ul > 0) + (*ur > 0) + (*lr > 0) + (*ll > 0)) 
  {
    default:  return;
    case 0:  break;
    case 1:  case 4:

      if (rand() % 2)   // Rotate neighborhood right.
	  {
        *ul = states[3];  *ur = states[0];
        *ll = states[2];  *lr = states[1];
      }
	  else            // Rotate neighborhood left.
	  {
        *ul = states[1];  *ur = states[2];
        *ll = states[0];  *lr = states[3];
      }

      break;

    case 2:

      // Diagnol neighborhood.
      if (((states[0] > 0) && (states[2] > 0)) ||
          ((states[1] > 0) && (states[3] > 0))) {
        if (rand() % 2) {  // Rotate neighborhood right.
          *ul = states[3];  *ur = states[0];
          *ll = states[2];  *lr = states[1];
        } else {           // Rotate neighborhood left.
          *ul = states[1];  *ur = states[2];
          *ll = states[0];  *lr = states[3];
        }
      } else { // Linear neighborhood.

        if (rand() % 3) {
          if (rand() % 2) {  // Rotate neighborhood right.
            *ul = states[3];  *ur = states[0];
            *ll = states[2];  *lr = states[1];
          } else {           // Rotate neighborhood left.
            *ul = states[1];  *ur = states[2];
            *ll = states[0];  *lr = states[3];
          }
        } else {

          // Figure out to swap up/down or left/right.
          if (((states[0] > 0) && (states[1] > 0)) ||
              ((states[2] > 0) && (states[3] > 0))) {  // North -> South
            *ul = states[3];  *ur = states[2];
            *ll = states[0];  *lr = states[1];
          }

          if (((states[1] > 0) && (states[2] > 0)) ||
              ((states[0] > 0) && (states[3] > 0))) {  // East -> West
            *ul = states[1];  *ur = states[0];
            *ll = states[2];  *lr = states[3];
          }
        }
      }

      break;

    case 3:

      if (rand() % 2) {    // No collisions just rotate the neighborhood.
        if (rand() % 2) {  // Rotate neighborhood right.
          *ul = states[3];  *ur = states[0];
          *ll = states[2];  *lr = states[1];
        } else {           // Rotate neighborhood left.
          *ul = states[1];  *ur = states[2];
          *ll = states[0];  *lr = states[3];
        }
      } else {             // One collision, only one cell can move.

        // Find the empty cell.
        for (i = 0; i < 4; i++)
          if (!states[i])
            break;

        // Slide an adjacent cell in to the empty cell.
        // I don't like this solution at all.
        if (i == 0) {        // Upper-left empty
          if (rand() % 2) {  // Slide in cell from south
            *ul = states[3];  *ur = states[1];
            *ll = states[0];  *lr = states[2];
          } else {           // Side in cell from right
            *ul = states[1];  *ur = states[0];
            *ll = states[3];  *lr = states[2];
          }
        } else {
          if (i == 1) {        // Upper-right empty
            if (rand() % 2) {  // Slide in cell from south
              *ul = states[0];  *ur = states[2];
              *ll = states[3];  *lr = states[1];
            } else {           // Side in cell from left
              *ul = states[1];  *ur = states[0];
              *ll = states[3];  *lr = states[2];
            }
          } else {
            if (i == 2) {        // Lower-right empty
              if (rand() % 2) {  // Slide in cell from north
                *ul = states[0];  *ur = states[2];
                *ll = states[3];  *lr = states[1];
              } else {           // Side in cell from left
                *ul = states[0];  *ur = states[1];
                *ll = states[2];  *lr = states[3];
              }
            } else {
              if (rand() % 2) {  // Slide in cell from north
                *ul = states[3];  *ur = states[1];
                *ll = states[0];  *lr = states[2];
              } else {           // Side in cell from right
                *ul = states[0];  *ur = states[1];
                *ll = states[2];  *lr = states[3];
              }
            }
          }
        }
      }
  }

  return;
}
//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 3;       // 1 - 1D, 2 - 2D, 3 - Margolus
  *CountOfColors = 17;  // count of states, 0..n-1
  strcpy(ColorPalette, "Rainbow008");
  strcpy(Misc, "");   // optional extra parameters; none supported at the moment
}
