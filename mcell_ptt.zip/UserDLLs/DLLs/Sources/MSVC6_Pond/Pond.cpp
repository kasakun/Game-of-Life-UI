// Pond.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}



#define STATES_CNT 3

static int states[STATES_CNT][5][5];


//
// Calculate the new state of the 'Me' cell.
int __declspec(dllexport) __stdcall CARule(int Generation,int col,int row,
                               int NW, int N,  int NE,
                               int W,  int Me, int E,
                               int SW, int S,  int SE)
{
  int i1Sum = 0;
  int i2Sum = 0;
  int newState;

  i1Sum = (N == 1) + (W == 1) + (E == 1) + (S == 1);
  i2Sum = (N == 2) + (W == 2) + (E == 2) + (S == 2);

  newState = states[Me][i1Sum][i2Sum];
  return newState;
}
//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 2;       // 1 - 1D, 2 - 2D
  *CountOfColors = STATES_CNT;  // count of states, 0..n-1
  strcpy(ColorPalette, "Rainbow008");  // optional color palette specification
  strcpy(Misc, "");   // optional extra parameters; none supported at the moment

  for (int i = 0; i < STATES_CNT; i++)
    for (int j = 0; j < 5; j++)
      for (int k = 0; k < 5; k++)
        states[i][j][k] = 0;

  states[0][0][0] = 0;
  states[0][0][1] = 0;
  states[0][0][2] = 0;
  states[0][0][3] = 0;
  states[0][0][4] = 0;

  states[0][1][0] = 1;
  states[0][1][1] = 2;
  states[0][1][2] = 2;
  states[0][1][3] = 2;

  states[0][2][0] = 1;
  states[0][2][1] = 2;
  states[0][2][2] = 0;

  states[0][3][0] = 1;
  states[0][3][1] = 2;

  states[0][4][0] = 0;

  states[1][0][0] = 1;
  states[1][0][1] = 0;
  states[1][0][2] = 0;
  states[1][0][3] = 0;
  states[1][0][4] = 0;

  states[1][1][0] = 1;
  states[1][1][1] = 2;
  states[1][1][2] = 2;
  states[1][1][3] = 0;

  states[1][2][0] = 0;
  states[1][2][1] = 0;
  states[1][2][2] = 0;

  states[1][3][0] = 1;
  states[1][3][1] = 2;

  states[1][4][0] = 1;

  states[2][0][0] = 0 ;
  states[2][0][1] = 0;
  states[2][0][2] = 0;
  states[2][0][3] = 0;
  states[2][0][4] = 0;

  states[2][1][0] = 2;
  states[2][1][1] = 0;
  states[2][1][2] = 0;
  states[2][1][3] = 0;

  states[2][2][0] = 2;
  states[2][2][1] = 2;
  states[2][2][2] = 2;

  states[2][3][0] = 2;
  states[2][3][1] = 2;

  states[2][4][0] = 2;
}
