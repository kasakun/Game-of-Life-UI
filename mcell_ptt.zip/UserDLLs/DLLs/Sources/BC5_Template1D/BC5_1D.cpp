// Borland C++ 5.02 example DLLs for MCell.
// Example template for a 1D rule by Brian Behlendorf.

#include <windows.h>
#pragma hdrstop

// Defines the entry and exit point for the DLL application.
int WINAPI DllEntryPoint(HINSTANCE, unsigned long, void *) {
  return 1;
} /* DllEntryPoint() */

// Sample 1D rule
// Calculate the new state of the 'Me' cell.
int __stdcall __declspec(dllexport) CARule1D(int Generation, int col,
    int l10, int l9, int l8, int l7, int l6, int l5,  int l4, int l3,
    int l2, int l1, int Me, int r1,  int r2, int r3, int r4, int r5,
    int r6,  int r7, int r8, int r9, int r10) {

  if (col > 0)
    return l1;

  if (col < -1)
    return r1;

  return ((Me + 1) % 8);
} /* CARule1D() */

// CAPass() is called before and after each cycle.
void __stdcall __declspec(dllexport) CAPass(int Generation,
    int Population, int PreFlag, char* Misc) {
  return;
} /* CAPass() */

// CAClose() is called when the DLL is freed (unloaded).
void __stdcall __declspec(dllexport) CAClose(int Generation, int Population) {
  return;
} /* CAClose() */

// CASetup() is called immediatelly after this rule is selected in MCell.
void __stdcall __declspec(dllexport) CASetup(int *RuleType,
    int *CountOfColors, char *ColorPalette, char *Misc) {
  *RuleType = 1;       // 1 - 1D; 2 - 2D
  *CountOfColors = 8;  // Number of states; (0..n-1)
  strcpy(ColorPalette, "Rainbow008");  // Optional color palette
  strcpy(Misc, "");    // Optional extra parameters; (none supported)
} /* CASetup() */
