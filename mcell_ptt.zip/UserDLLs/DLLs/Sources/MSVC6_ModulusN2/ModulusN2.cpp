// ModulusN2.cpp : Defines the entry point for the DLL application.
//
// Add up the von Neumann 5 neighbors and return the sum mod 2.
// By: Dave Hiebeler
// August 1989
//

#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}



//
// Calculate the new state of the 'Me' cell.
int __declspec(dllexport) __stdcall CARule(int Generation,int col,int row,
                               int NW, int N,  int NE,
                               int W,  int Me, int E,
                               int SW, int S,  int SE)
{
  return (N + E + S + W + Me) % 2;
}
//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 2;       // 1 - 1D, 2 - 2D
  *CountOfColors = 2;  // count of states, 0..n-1
  strcpy(ColorPalette, "3 colors");  // optional color palette specification
  strcpy(Misc, "");   // optional extra parameters; none supported at the moment
}
