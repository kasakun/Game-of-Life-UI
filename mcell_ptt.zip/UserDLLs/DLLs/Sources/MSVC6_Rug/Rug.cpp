// Rug.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

//
// Calculate the new state of the 'Me' cell.
int __declspec(dllexport) __stdcall CARule(int Generation,int col,int row,
                               int NW, int N,  int NE,
                               int W,  int Me, int E,
                               int SW, int S,  int SE)
{
	int sum8 = NW + N + NE + W + E + SW + S + SE;

  return ((sum8 / 8) + 1) % 256;
}

//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void  __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 2;       // 1 - 1D, 2 - 2D
  *CountOfColors = 256;  // 256 states, 0..255
  strcpy(ColorPalette, "MCell standard");  // color palette specification
  strcpy(Misc, "ALLCELLS");   // no optimizing
}
